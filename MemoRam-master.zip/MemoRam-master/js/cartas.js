let cardArray = [ 
    { name: "fries", img: "fries.png", }, 
    { name: "fries", img: "fries.png", },
    { name: "pizza", img: "pizza.png", },
    { name: "pizza", img: "pizza.png", }, 
    { name: "milkshake", img: "milkshake.png", },
    { name: "milkshake", img: "milkshake.png", }, 
    { name: "ice-cream", img: "ice-cream.png", },
    { name: "ice-cream", img: "ice-cream.png", },
    { name: "hotdog", img: "hotdog.png", },
    { name: "hotdog", img: "hotdog.png", },
    { name: "cheeseburger", img: "cheeseburger.png", },
    { name: "cheeseburger", img: "cheeseburger.png", }, 
    ]; 